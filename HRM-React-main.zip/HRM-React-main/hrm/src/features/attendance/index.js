// attendance/index.js
export { default as AttendancePage } from './AttendancePage';

