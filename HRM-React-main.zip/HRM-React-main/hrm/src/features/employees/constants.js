export const PER_PAGE_OPTIONS = [10, 25, 50, 100];
